# [PROGRAM NAME] 
[a description of the program]

## Getting Started
---
[how to install and run the program]

## Project Structure
---
The project files and folders are organized as follows:
```
root                    (project root folder)
+-- docs                (project documentation)
+-- rename              [rename this folder and description]
  +-- assets            (program asset files)
  +-- data              (program data files)
  +-- game              (program source code)
  +-- __init__.py       (python package file)
  +-- __main__.py       (entry point for program)
+-- LICENSE             (license file)
+-- README.md           (general info)
```

## Required Technologies
---
[list required libraries]

## Authors
---
[list author names and emails]
