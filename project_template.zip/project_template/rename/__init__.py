"""
The root package for the program.
"""