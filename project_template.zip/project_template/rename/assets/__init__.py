"""
The assets package contains images, sounds and other assets used by the program.
"""