"""
The game package contains the source code for the program.
"""